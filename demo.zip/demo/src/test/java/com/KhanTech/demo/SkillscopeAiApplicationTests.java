package com.KhanTech.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkillscopeAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
