package com.KhanTech.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkillscopeAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkillscopeAiApplication.class, args);
	}

}
